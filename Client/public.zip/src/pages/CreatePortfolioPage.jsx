import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import TemplateOne from "../components/templates/TemplateOne";
import TemplateTwo from "../components/templates/TemplateTwo";

const templates = [
  {
    id: 1,
    title: "Professional",
    description: "Build your personal portfolio",
  },
  {
    id: 2,
    title: "Company",
    description: "Create a professional company portfolio",
  },
  {
    id: 3,
    title: "Event Manager",
    description: "Showcase your event management services",
  },
];

const CreatePortfolio = () => {
  const navigate = useNavigate();

  return (
    
    <Container sx={{ mt: 6 }}>
      <Typography variant="h4" align="center" gutterBottom>
        Create Your Company Portfolio
      </Typography>
      <Typography align="center" sx={{ mb: 4 }}>
        Choose a category to get started
      </Typography>

      <Grid container spacing={4} justifyContent="center">
        {templates.map((template) => (
          <Grid item xs={12} sm={6} md={4} key={template.id}>
            <Card sx={{ border: "1px solid #FFCC00", borderRadius: 3 }}>
              <CardContent sx={{ textAlign: "center" }}>
                <Typography variant="h6" gutterBottom>
                  {template.title}
                </Typography>
                <Typography variant="body2" sx={{ mb: 2 }}>
                  {template.description}
                </Typography>
                <Button
                  variant="contained"
                  onClick={() => navigate(`/create-portfolio/${template.title}`)}
                  color="primary"
                >
                  Get Started →
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
      <TemplateTwo/>
    </Container>
  );
};

export default CreatePortfolio;
