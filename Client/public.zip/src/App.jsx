import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/shared/Navbar";
import Home from "./pages/Home";
import CreatePortfolio from "./pages/CreatePortfolioPage";
import TemplateOne from "./components/templates/TemplateOne";
import PortfolioPage from "./pages/PortfolioPage";

const App = () => {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/portfolio/:id" element={<PortfolioPage />} />

        <Route path="/create-portfolio" element={<CreatePortfolio />} />
      </Routes>
    </>
  );
};

export default App;
